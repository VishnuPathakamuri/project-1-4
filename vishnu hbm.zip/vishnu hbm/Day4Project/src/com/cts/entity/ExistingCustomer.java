package com.cts.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="CTS_ExistingCustomer")
public class ExistingCustomer extends Customer{

}
