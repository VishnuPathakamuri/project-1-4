package com.cts.dao;

import java.util.List;
import java.util.Random;

import javax.net.ssl.SSLEngineResult.Status;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.cts.entity.Booking;
import com.cts.entity.Customer;
import com.cts.entity.Event;
import com.cts.entity.Location;
import com.cts.util.HibernateUtil;

public class BookingDao {
	private SessionFactory sf;
	private Session ses;
	private Status status;
	private Location loc;
	private Customer cust;
	private Event event;
	private Booking booking;
	
	public BookingDao (){
		sf=HibernateUtil.Getfactory();
	}
	
	public int InsertLocation(Location location){
		location=loc;
		ses=sf.openSession();
		ses.beginTransaction();
		int pk=0;
		try{
		
		pk=(int) ses.save(location);
		ses.getTransaction().commit();
		
		}
		catch(HibernateException e){
			ses.getTransaction().rollback();
		}
		ses.close();
		return 0;
		
	}
	
	public void InsertEvent(Event event, int locationId){
		event=event;
		ses=sf.openSession();
		Location resultLoc=(Location) ses.get(Location.class, locationId);
		ses.beginTransaction();
		try{
		
		//ses.persist(loc);
		event.setLocation(resultLoc);
		ses.persist(event);
		ses.getTransaction().commit();
		}
		catch(HibernateException e){
			ses.getTransaction().rollback();
		}
		ses.close();
	}
	
	public void InsertBooking(Booking booking){
		
		
	}
	
    public void InsertCustomer(Customer customer){
		
		
	}
	
	public boolean insertLocation(){
		boolean status=false;
		sf=HibernateUtil.Getfactory();
		ses=sf.openSession();
		ses.beginTransaction();
		Random random=new Random();
		Location location=null;
		try{
			
		for(int i=0;i<100;i++){
			location=new Location();
			location.setLocationName("CTS"+random.nextInt(100));
			ses.save(location);
			if(i%2==0){
			ses.flush();	
			}
		}
		ses.getTransaction().commit();
		status=true;
		}
		catch(HibernateException e){
			ses.getTransaction().rollback();
		}
		return status;
	}
	
	public List<Location> GetLocationByName(String name){
		sf=HibernateUtil.Getfactory();
		ses=sf.openSession();
		//ses.beginTransaction();
		//Location locc=(Location) ses.createQuery("from Location where LocationName=?");
		//Query qry=ses.createQuery("from Location where locationName=?");
		/*Query qry=ses.getNamedQuery("GetLocationByName");
		qry.setParameter(0, name);
		return (Location) qry.list().get(0);*/ 
		
	Criteria cri=ses.createCriteria(Location.class);
		cri.add(Restrictions.gt("locationId",85));
		cri.add(Restrictions.like("locationName", "CTS%"));
		return cri.list();
	}
	
	
	public long GetLocation(){
		sf=HibernateUtil.Getfactory();
		ses=sf.openSession();
		ses.beginTransaction();
		Query qry=ses.createQuery("select count(loc.locationName) from Location loc");
		return  (long) qry.list().get(0);
		
	}
	
public int GetMaxLocationId(){
	sf=HibernateUtil.Getfactory();
	ses=sf.openSession();
	ses.beginTransaction();
	Query qry=ses.createQuery("select max(loc.locationId) from Location loc");
	return  (int) qry.list().get(0);
		
	}
	
public List<Location> SortLocation(){
	sf=HibernateUtil.Getfactory();
	ses=sf.openSession();
	Query qry=ses.createQuery("from Location loc order by  loc.locationName asc");
	return  qry.list();
	}
	

public List<Location> DscLocation(){
	sf=HibernateUtil.Getfactory();
	ses=sf.openSession();
	Query qry=ses.createQuery("from Location loc order by loc.locationName desc");
	return  qry.list();
	}

public int GetMaxSecondLocationId(){
	sf=HibernateUtil.Getfactory();
	ses=sf.openSession();
	ses.beginTransaction();
	Query qry=ses.createQuery("select max(l.locationId)from Location l where l.locationId < (select max(loc.locationId) from Location loc)");
	return  (int) qry.list().get(0);
		
	}

}
