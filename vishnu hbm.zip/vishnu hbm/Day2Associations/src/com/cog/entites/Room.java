package com.cog.entites;

public class Room {

}
