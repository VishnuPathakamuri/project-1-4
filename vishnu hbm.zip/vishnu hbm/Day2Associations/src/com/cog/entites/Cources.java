package com.cog.entites;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="flipCources")
public class Cources {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CourcesId")
	private int courcesId;
	@Column(name="CourcesName")
	private String courcesName;
	
	@ManyToMany(mappedBy="courcesList")
	/*(cascade=CascadeType.ALL)
	@JoinTable(name="Traini_Cources",
	           joinColumns={@JoinColumn(name="Course_Id")},
	           inverseJoinColumns={@JoinColumn(name="Traini_Id")})*/
	private List<Traini> trainiList;
	
	
	
	public int getCourcesId() {
		return courcesId;
	}
	public void setCourcesId(int courcesId) {
		this.courcesId = courcesId;
	}
	public String getCourcesName() {
		return courcesName;
	}
	public void setCourcesName(String courcesName) {
		this.courcesName = courcesName;
	}
	public List<Traini> getTrainiList() {
		return trainiList;
	}
	public void setTrainiList(List<Traini> trainiList) {
		this.trainiList = trainiList;
	}
	
}
