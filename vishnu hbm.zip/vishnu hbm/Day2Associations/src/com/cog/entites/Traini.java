package com.cog.entites;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="flipTraini")
public class Traini {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="TrainiId")
	private int trainiId;
	@Column(name="TrainiName")
	private String trainiName;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="Traini_Cources",
	           joinColumns={@JoinColumn(name="Traini_Id")},
	           inverseJoinColumns={@JoinColumn(name="Course_Id")})
	private List<Cources> courcesList;
	
	
	public int getTrainiId() {
		return trainiId;
	}
	public void setTrainiId(int trainiId) {
		this.trainiId = trainiId;
	}
	public String getTrainiName() {
		return trainiName;
	}
	public void setTrainiName(String trainiName) {
		this.trainiName = trainiName;
	}
	public List<Cources> getCourcesList() {
		return courcesList;
	}
	public void setCourcesList(List<Cources> courcesList) {
		this.courcesList = courcesList;
	}
	
}
