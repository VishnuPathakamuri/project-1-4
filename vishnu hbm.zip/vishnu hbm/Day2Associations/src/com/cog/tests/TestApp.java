package com.cog.tests;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.cog.dao.DaoManager;
import com.cog.entites.Address;
import com.cog.entites.Author;
import com.cog.entites.Book;
import com.cog.entites.Cources;
import com.cog.entites.Customer;
import com.cog.entites.Players;
import com.cog.entites.Team;
import com.cog.entites.Traini;

public class TestApp {
public static void main(String[] args) {
	DaoManager dao=new DaoManager();
	
	/*Address add=new Address();
	Customer cust=new Customer();
	add.setStreet("ongolee");
	add.setCity("javaavv");
	cust.setName("vishnu");
	cust.setDob(new Date(7885,5,8));
	dao.AddCustomer_Address(cust, add);*/
	
	/*Iterator itr=  dao.GetAll().iterate();
	System.out.println("customerId"+"\t"+"name"+"\t"+"city"+"\t"+"street");
	while(itr.hasNext()){
		//System.out.println(itr.next());
		Object[] obj=(Object[]) itr.next();
		System.out.println(obj[0]+"\t"+obj[1]+"\t"+obj[2]+"\t"+obj[3]);
	}*/
	
	/*Book book =new Book();
	Author author= new Author();
	author.setAuthorName("sivaaaa");
	book.setBookName("book name");
	book.setDop(new Date(5554,5,8));
	dao.AddBook_Author(book, author);*/
	
/*Team team=new Team();
	team.setTeamName("ongole");
	List<Players> playerlist=new ArrayList<Players>();
	Players players=new Players();
 
	players.setPlayerName("vishnu");
	players.setTeam(team);
	playerlist.add(players);
	 players=new Players();
	players.setPlayerName("sachin");
	players.setTeam(team);
	playerlist.add(players);
	 players=new Players();
	players.setPlayerName("virat");
	players.setTeam(team);
	playerlist.add(players);
	
	dao.AddTeam_Players(team, playerlist);*/
	
	
	/*for (Team team : dao.GetAllPlayers()) {
		System.out.println(team.getTeamName());
		for (Players player : team.getPlayerList()) {
			System.out.println(player.getPlayerName());
		}
	}*/
	
	
	
	Cources cources=new Cources();
	List<Traini> trainiList=new ArrayList<Traini>();
	List<Cources> courcesList=new ArrayList<Cources>();
	
	Traini traini= new Traini();
	traini.setTrainiName("parameswari");
	trainiList.add(traini);
	
	traini= new Traini();
	traini.setTrainiName("hsdhsbh");
	trainiList.add(traini);
	
	traini= new Traini();
	traini.setTrainiName("bxjbsj");
	trainiList.add(traini);
	
	traini= new Traini();
	traini.setTrainiName("bbsjbxd");
	trainiList.add(traini);
	
	cources.setCourcesName("java");
	cources.setTrainiList(trainiList);
	courcesList.add(cources);
	dao.AddTraini_Cources(trainiList, courcesList);
	
	
	
	
	
}

}
