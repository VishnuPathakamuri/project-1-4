package com.cog.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cog.entites.Address;
import com.cog.entites.Author;
import com.cog.entites.Book;
import com.cog.entites.Cources;
import com.cog.entites.Customer;
import com.cog.entites.Players;
import com.cog.entites.Team;
import com.cog.entites.Traini;
import com.cog.utilities.HibernateUtil;

public class DaoManager {

	private SessionFactory sf;
	private Session ses;
	private boolean status;
	
	public DaoManager(){
		sf=HibernateUtil.Getfactory();
	}
	
	public boolean AddCustomer_Address(Customer customer,Address address){
		ses=sf.openSession();
		ses.beginTransaction();
		try{
			ses.save(address);
			customer.setAddress(address);
			ses.persist(customer);
			ses.getTransaction().commit();
			status=true;
		}
		catch(HibernateException e){
			ses.getTransaction().rollback();
		}
		
		return status;
	}
	
	
	public Query GetAll(){
		ses=sf.openSession();
		return ses.createQuery("select cust.customerId,cust.name,addr.street,addr.city from "
				                + "Customer cust inner join cust.address addr");
	}
	
	
	public boolean AddBook_Author(Book book,Author author) {
		ses=sf.openSession();
		ses.beginTransaction();
		try{
			author.setBook(book);
			//ses.save(book);
			book.setAuthor(author);
			ses.persist(book);
			ses.getTransaction().commit();
			status=true;
		}
		catch(HibernateException e){
			ses.getTransaction().rollback();
		}
		
		return status;
	}
	
	
	
	public boolean AddTeam_Players(Team team,List<Players> playersList) {
		ses=sf.openSession();
		ses.beginTransaction();
		try{
			
			team.setPlayerList(playersList);
			ses.save(team);
			ses.getTransaction().commit();
			status=true;
		}
		catch(HibernateException e){
			ses.getTransaction().rollback();
		}
		
		return status;
	}
		
	public List<Team> GetAllPlayers(){
		ses=sf.openSession();
		/*return ses.createQuery("select team.teamId,team.teamName,player.playerName from "
				                + "Team team inner join team.playerList player");*/
		return ses.createQuery("from Team").list();
	}
	
	
	public boolean AddTraini_Cources(List<Traini> trainiList,List<Cources> courcesList) {
		ses=sf.openSession();
		ses.beginTransaction();
		try{
			for (Traini traini : trainiList) {
				traini.setCourcesList(courcesList);
				ses.save(traini);
			}
			
			ses.getTransaction().commit();
			status=true;
		}
		catch(HibernateException e){
			ses.getTransaction().rollback();
		}
		
		return status;
	}
	
	
	
	
	
	
	
	
	
	
	

}
