package com.cog.tests;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cog.dao.DaoManager;
import com.cog.entites.CreditCard;
import com.cog.entites.DebitCard;
import com.cog.entites.Payment;

public class PaymentTest {

	private DaoManager dm;

	@Before
	public void setUp() throws Exception {
		dm= new DaoManager();
	}
 
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void paymentTest() {
		//fail("Not yet implemented");
		Payment pm=new Payment();
		pm.setCustomerId(1);
		pm.setAmount(53153);
		pm.setDOT(new Date(5148,5,6));
		assertTrue(dm.AddPayment(pm));
	}
	
	@Test
	public void CreditTest() {
		 // fail("Not yet implemented");
		CreditCard cd=new CreditCard();
		cd.setCustomerId(1);
		cd.setAmount(65156);
		cd.setcExpiryDate(new Date(4464,89,5));
		cd.setCreditCardName("vishnu");
		cd.setCreditCardNo(5463);
		cd.setCvv(414);
	    cd.setDOT(new Date(4654,5,4));
	    cd.setEMI(true);
		assertTrue(dm.AddPayment(cd));
	}

	@Test
	public void DebitTest() {
		 // fail("Not yet implemented");
		DebitCard db=new DebitCard();
		db.setCustomerId(1);
		db.setdExpiryDate(new Date(5665,5,5));
		db.setDebitCardName("fhuihfi");
		db.setDebitCardNo(6556456);
		db.setDvv(5556);
		db.setDOT(new Date(5454,8,6));
		assertTrue(dm.AddPayment(db));
	}
	
	
	
	
	
}
