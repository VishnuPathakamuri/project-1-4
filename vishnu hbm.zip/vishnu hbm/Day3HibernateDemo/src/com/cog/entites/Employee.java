package com.cog.entites;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="CTSEmployee")
//@PrimaryKeyJoinColumn(name="AdhaarId",referencedColumnName="AdhaarNo")
public class Employee extends Person{
	@Column(name="EmployeeNo")
	private int employeeNo;
	
	@Column(name="Location")
	private String location;
	
	@Column(name="Project")
	private String project;

	public int getEmployeeNo() {
		return employeeNo;
	}

	public void setEmployeeNo(int employeeNo) {
		this.employeeNo = employeeNo;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

}
