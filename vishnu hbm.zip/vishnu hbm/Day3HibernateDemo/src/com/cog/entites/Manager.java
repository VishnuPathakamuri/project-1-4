package com.cog.entites;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="CTSManager")
//@PrimaryKeyJoinColumn(name="AdhaarId",referencedColumnName="AdhaarNo")
//@PrimaryKeyJoinColumn(name="EmployeeId",referencedColumnName="EmployeeNo")
public class Manager extends Employee{
	
	@Column(name="NoOfProjects")
	private int noOfProjects;
	
	@Column(name="LeaveApproval")
	private boolean leaveApproval;
	
	
	public int getNoOfProjects() {
		return noOfProjects;
	}
	public void setNoOfProjects(int noOfProjects) {
		this.noOfProjects = noOfProjects;
	}
	public boolean isLeaveApproval() {
		return leaveApproval;
	}
	public void setLeaveApproval(boolean leaveApproval) {
		this.leaveApproval = leaveApproval;
	}
	
	
	

}
