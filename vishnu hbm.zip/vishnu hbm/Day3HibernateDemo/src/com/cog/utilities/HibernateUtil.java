package com.cog.utilities;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	

	public  static SessionFactory Getfactory(){
		return new Configuration().configure("com/cog/resources/hibernate.cfg.xml").buildSessionFactory();
		
	}

}
