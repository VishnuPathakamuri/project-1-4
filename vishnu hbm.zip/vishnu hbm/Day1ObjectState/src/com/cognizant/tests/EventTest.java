package com.cognizant.tests;

import static org.junit.Assert.*;
import org.junit.Test;
import com.cognizant.dao.EventManager;
import com.cognizant.entities.Event;
import com.cognizant.entities.EventKey;


public class EventTest {
	@Test
	public void test()  {
		EventManager em=new EventManager();
		EventKey ek=new EventKey();
		ek.setEventId(1);
		ek.setTrainerId(53);
	Event e=new Event();
	    e.setEk(ek);
		e.setDuration(5);
		e.setLocation("chennai");
		e.setEventName("hhfy");
		assertTrue(em.AddEvent(e));
	}
	
}
