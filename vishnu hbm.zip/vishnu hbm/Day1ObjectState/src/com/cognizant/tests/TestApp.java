package com.cognizant.tests;

import java.util.Scanner;




import com.cognizant.dao.EventManager;
import com.cognizant.dao.RoomManager;
import com.cognizant.entities.Event;
import com.cognizant.entities.EventKey;
import com.cognizant.entities.Room;

public class TestApp {

	/*public static void main1(String[] args) {
		
		RoomManager roomManager= new RoomManager();
		Room room=new Room();
		room.setCapacity(4125);
		room.setLocation("dfsfsf");
		room.setProj_ava(true);
	    room.setSys_ava(true);
	    if(roomManager.addRoom(room))
	    	System.out.println("record added");
		
		
		for (Room room1 : roomManager.GetAllRooms()) {
			System.out.println(room1.getRoomNo()+"\t");
			System.out.println(room1.getCapacity());
		}
		
	    
		Scanner sc=new Scanner(System.in);
		System.out.println("enter room no");
        Integer roomNo=sc.nextInt();
		roomManager.updateRoom(roomNo);
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter room no1");
        Integer roomNo1=sc.nextInt();
        System.out.println("enter room no2");
        Integer roomNo2=sc.nextInt();
		roomManager.roomEvict_clear(roomNo1, roomNo2);
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter room no1");
        int roomNo=sc.nextInt();
        roomManager.SessionClose(roomNo);
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter room no");
        Integer roomNo=sc.nextInt();
		roomManager.deleteRoom(roomNo);*/
		
		
        public static void main(String[] args) { 
        	EventManager em=new EventManager();
        	EventKey ek=new EventKey();
        	ek.setEventId(1);
        	ek.setTrainerId(53);
  Event e=new Event();
            e.setEk(ek);
        	e.setDuration(5);
        	e.setLocation("chennai");
        	e.setEventName("hhfy");
        	em.AddEvent(e);
        	
        	
        }
		
	}

