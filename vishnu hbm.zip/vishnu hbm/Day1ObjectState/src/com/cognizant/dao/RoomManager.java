package com.cognizant.dao;


import java.util.List;

import javax.management.Query;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.entities.Room;
import com.cognizant.utilities.HibernateUtil;




public class RoomManager {

	private SessionFactory factory;
	private Session session;
	
	public RoomManager(){
		factory=HibernateUtil.Getfactory();
	}
	
	
	public boolean addRoom(Room room){
		
		boolean status=false;
		factory=HibernateUtil.Getfactory();
		session= factory.openSession();
		session.beginTransaction();
		try {
			session.save(room);
			session.getTransaction().commit();
			status = true;
		} catch (HibernateException e) {
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	
	
	
	public List<Room> GetAllRooms() {
		session = factory.openSession();
		// Query query=session.createQuery("from Room");
		return session.createQuery("from Room").list();
	}
	
	
	
	public boolean updateRoom(int roomNo){
		boolean status=false;
		Room room=(Room) session.get(Room.class, roomNo);
		room.setCapacity(252);
		room.setSys_ava(false);
		session.beginTransaction();
		try {
			//session.update(room);
			session.getTransaction().commit();
			status = true;
		} 
		catch (HibernateException e) {
			session.getTransaction().rollback();
		}
		session.close();
		
		return status;
	}
	
	public boolean deleteRoom(int roomNo){
		boolean status=false;
		Room room=(Room) session.get(Room.class, roomNo);
		room.setCapacity(252);
		room.setSys_ava(false);
		session.beginTransaction();
		try {
			session.delete(room);
			session.getTransaction().commit();
			status = true;
		} 
		catch (HibernateException e) {
			session.getTransaction().rollback();
		}
		session.close();
		
		return status;
	}
	
	
	public boolean roomEvict_clear(int roomNo1,int roomNo2){
		boolean status=false;
		session=factory.openSession();
		Room room11=(Room) session.get(Room.class, roomNo1);
		Room room22=(Room) session.get(Room.class, roomNo2);
	//modify room11,room22
		//session.evict(room11);
		session.clear();
		session.beginTransaction();
		room11.setCapacity(74);
		room22.setCapacity(874);
		session.getTransaction().commit();
		status=true;
		session.close();
		return status;
	}
	
	public boolean SessionClose(int roomNo){
	boolean status=false;
	session=factory.openSession();
	session.beginTransaction();
	Room room=(Room)session.get(Room.class, roomNo);
	
	session.close();
	room.setCapacity(67);
	Session ses1=factory.openSession();
	
	Room room1=(Room) ses1.get(Room.class, roomNo);
	ses1.beginTransaction();
	ses1.merge(room);
	session.getTransaction().commit();
	status=true;
	return status;
	}
	

	/*public boolean SessionClose(int roomNo){
		boolean status = false;
				session = factory.openSession();
				session.beginTransaction();

				Room room =(Room)session.get(Room.class, roomNo);
				session.close();
				room.setCapacity(67);
				
				
				Session session1 = factory.openSession();
				Room room1 = (Room)session1.get(Room.class,roomNo);
				session1.beginTransaction();

				session1.merge(room);
				
				session1.getTransaction().commit();
				status = true;
				return status; 

	}*/









}

